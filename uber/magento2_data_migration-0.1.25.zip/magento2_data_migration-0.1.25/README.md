# Magento 2 data migration tool #

## Author: <a href="http://www.ubertheme.com" target="_blank" title="UberTheme">UberTheme</a>

### Compatible: ###
- We are going to support the following versions for magento 2 data migration:
    + Magento Community Edition (CE) versions: 1.6.x, 1.7.x, 1.8.x, CE 1.9.x
    + Magento 2 CE 2.0.0 and later

### How To Install: ###
- We have released a Magento 2 module for this tool.
- To use this tool let's click <a href="https://github.com/ubertheme/module-ubdatamigration/blob/master/README.md" title="How to install magento 2 data migration tool">HERE</a>



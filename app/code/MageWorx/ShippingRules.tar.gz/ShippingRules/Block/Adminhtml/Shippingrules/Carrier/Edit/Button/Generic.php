<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Block\Adminhtml\Shippingrules\Carrier\Edit\Button;

use Magento\Framework\Registry;
use MageWorx\ShippingRules\Model\Carrier;
use MageWorx\ShippingRules\Model\CarrierFactory;
use Magento\Framework\View\Element\UiComponent\Context;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class Generic implements ButtonProviderInterface
{
    /**
     * Url Builder
     *
     * @var Context
     */
    protected $context;

    /**
     * Registry
     *
     * @var Registry
     */
    protected $registry;

    /**
     * @var CarrierFactory
     */
    protected $carrierFactory;

    /**
     * Generic constructor
     *
     * @param Context $context
     * @param Registry $registry
     * @param CarrierFactory $carrierFactory
     */
    public function __construct(
        Context $context,
        Registry $registry,
        CarrierFactory $carrierFactory
    ) {
        $this->context = $context;
        $this->registry = $registry;
        $this->carrierFactory = $carrierFactory;
    }

    /**
     * Generate url by route and parameters
     *
     * @param string $route
     * @param array $params
     * @return string
     */
    public function getUrl($route = '', $params = [])
    {
        /** @var Context $context */
        $context = $this->context;
        /** @var string $url */
        $url = $context->getUrl($route, $params);

        return $url;
    }

    /**
     * Get carrier
     *
     * @return \MageWorx\ShippingRules\Model\Carrier
     */
    public function getCarrier()
    {
        $carrier = $this->registry->registry(Carrier::CURRENT_CARRIER);
        if (!$carrier) {
            $carrier = $this->carrierFactory->create();
        }

        return $carrier;
    }

    /**
     * {@inheritdoc}
     */
    public function getButtonData()
    {
        return [];
    }
}

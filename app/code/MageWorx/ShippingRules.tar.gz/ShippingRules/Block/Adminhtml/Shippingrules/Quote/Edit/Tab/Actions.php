<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\ShippingRules\Block\Adminhtml\Shippingrules\Quote\Edit\Tab;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Form\Renderer\Fieldset;
use Magento\Framework\Data\FormFactory;
use Magento\Framework\Registry;
use MageWorx\ShippingRules\Model\Config\Source\Shipping\Methods as Config;
use MageWorx\ShippingRules\Model\Config\Source\Shipping\ExtendedActions as ShippingActionsConfig;
use MageWorx\ShippingRules\Model\Rule;
use Magento\Framework\Convert\DataObject as ObjectConverter;
use Magento\Config\Model\Config\Source\Yesno;

class Actions extends \Magento\Backend\Block\Widget\Form\Generic implements
    \Magento\Backend\Block\Widget\Tab\TabInterface
{

    const HIDDEN_FIELDSET_CLASS_NAME = 'hidden-fieldset';

    /**
     * Core registry
     *
     * @var Fieldset
     */
    protected $rendererFieldset;

    /** @var Config */
    protected $shippingConfig;

    /** @var Config */
    protected $shippingActionsConfig;

    /** @var \Magento\Framework\Convert\DataObject */
    protected $objectConverter;

    /** @var Yesno  */
    protected $yesNoConfig;

    /** @var \MageWorx\ShippingRules\Model\Rule */
    protected $sourceModel;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param Fieldset $rendererFieldset
     * @param Config $config
     * @param ObjectConverter $objectConverter
     * @param ShippingActionsConfig $shippingActionsConfig
     * @param Yesno $yesno
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        Fieldset $rendererFieldset,
        Config $config,
        ObjectConverter $objectConverter,
        ShippingActionsConfig $shippingActionsConfig,
        Yesno $yesno,
        array $data = []
    ) {
        $this->rendererFieldset = $rendererFieldset;
        $this->shippingConfig = $config;
        $this->shippingActionsConfig = $shippingActionsConfig;
        $this->objectConverter = $objectConverter;
        $this->yesNoConfig = $yesno;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Actions');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Actions');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Prepare amounts for form
     *
     * @param Rule $model
     * @return Rule
     */
    protected function _prepareModel(Rule $model)
    {
        $amounts = $model->getAmount();

        if (empty($amounts)) {
            return $model;
        }

        foreach ($amounts as $amountKey => $amountData) {
            $valueKey = 'amount_' . $amountKey . '_value';
            $value = $amountData['value'] * 1;
            $model->setData($valueKey, $value);

            $sortOrderKey = 'amount_' . $amountKey . '_sort';
            $sortOrderValue = $amountData['sort'] * 1;
            $model->setData($sortOrderKey, $sortOrderValue);
        }

        return $model;
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('current_promo_quote_rule');
        $model = $this->_prepareModel($model);
        $this->sourceModel = $model;

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('rule_');

        $this->addMainFieldset($form);
        $this->addModifyCostFieldset($form);
        $this->addHideShippingMethodsFieldset($form);

        $this->rendererFieldset->setTemplate(
            'Magento_CatalogRule::promo/fieldset.phtml'
        )->setNewChildUrl(
            $this->getUrl('mageworx_shippingrules/shippingrules_quote/newActionHtml/form/rule_actions_fieldset')
        );

        $this->_eventManager->dispatch('adminhtml_block_shippingrules_actions_prepareform', ['form' => $form]);

        $form->setValues($model->getData());

        $this->setForm($form);
        return parent::_prepareForm();
    }

    /**
     * Add the fieldset with ability to hide selected shipping methods
     *
     * @param $form
     * @return mixed
     */
    protected function addHideShippingMethodsFieldset($form)
    {
        $modelActionType = $this->getSourceModelActionType();
        $hidden = !in_array(Rule::ACTION_DISABLE_SM, $modelActionType) ? self::HIDDEN_FIELDSET_CLASS_NAME : '';
        $classes = 'dependable_fieldset_' . Rule::ACTION_DISABLE_SM . ' ' . $hidden;
        $hideSMFieldset = $form->addFieldset(
            'hide_shipping_method_fieldset',
            ['legend' => __('Hide Shipping Method'), 'class' => $classes]
        );

        $shippingmethods = $this->getShippingMethods();
        $hideSMFieldset->addField(
            'disabled_shipping_methods',
            'multiselect',
            [
                'name' => 'disabled_shipping_methods[]',
                'label' => __('Disabled Shipping Methods'),
                'title' => __('Disabled Shipping Methods'),
                'values' =>  $shippingmethods
            ]
        );

        return $hideSMFieldset;
    }

    /**
     * Add the modify cost fieldset
     *
     * @param $form
     * @return mixed
     */
    protected function addModifyCostFieldset($form)
    {

        $modelActionType = $this->getSourceModelActionType();
        $hidden = !in_array(Rule::ACTION_OVERWRITE_COST, $modelActionType) ? self::HIDDEN_FIELDSET_CLASS_NAME : '';
        $classes = 'dependable_fieldset_' . Rule::ACTION_OVERWRITE_COST . ' ' . $hidden;
        $modifyCostFieldset = $form->addFieldset(
            'modify_cost_fieldset',
            ['legend' => __('Modify Shipping Cost'), 'class' => $classes]
        );

        // How calculate
        $actions = $this->shippingActionsConfig->toOptionArray();
        $simpleActionField = $modifyCostFieldset->addField(
            'simple_action',
            'multiselect',
            [
                'label' => __('Method'),
                'name' => 'simple_action',
                'onchange' => 'changeAmounts(this)',
                'values' => $actions
            ]
        );

        $simpleActionField->setAfterElementHtml("<script>
            require(['jquery', 'jquery/ui'], function($){
                $('#rule_simple_action').trigger('change');
            });

            function changeAmounts(e) {

                var values = jQuery(e).val();

                try {
                    jQuery('.amount-field').each(function() {
                        jQuery(this).closest('.field').hide();
                    });

                    jQuery(values).each(function(){
                        var className = '.amount-field.'+this;
                        jQuery(className).closest('.field').show();
                    });
                } catch (e) {
                    console.log(e);
                }
            }
        </script>");

        $this->_addAmountFields($actions, $modifyCostFieldset, $this->sourceModel);

        // All available shipping methods
        $shippingmethods = $this->getShippingMethods();
        $modifyCostFieldset->addField(
            'shipping_methods',
            'multiselect',
            [
                'name' => 'shipping_methods[]',
                'label' => __('Apply to Shipping Methods'),
                'title' => __('Apply to Shipping Methods'),
                'values' =>  $shippingmethods
            ]
        );

        return $modifyCostFieldset;
    }

    /**
     * Add main fieldset with action type and stop future rules processing select.
     *
     * @param $form
     * @return mixed
     */
    protected function addMainFieldset($form)
    {

        $mainFieldset = $form->addFieldset(
            'action_fieldset',
            ['legend' => __('Rule\'s Action')]
        );

        // What to do
        $actionType = $mainFieldset->addField(
            'action_type',
            'checkboxes',
            [
                'label' => __('Type'),
                'name' => 'action_type[]',
                'required' => true,
                'onchange' => 'changeActions(this)',
                'values' => [
                    ['value' => Rule::ACTION_OVERWRITE_COST, 'label' => __('Modify Shipping Cost')],
                    ['value' => Rule::ACTION_DISABLE_SM, 'label' => __('Hide Shipping Method')]
                ]
            ]
        );

        $actionType->setAfterElementHtml("<script>
        function changeActions(selectItem){
            var item = jQuery(selectItem);
            var targetClass = '.dependable_fieldset_'+item.val();
            var target = jQuery(targetClass);
            target.toggleClass('hidden-fieldset');
        }
        </script>");

        // Stop future rules processing
        $mainFieldset->addField(
            'stop_rules_processing',
            'select',
            [
                'label' => __('Stop Further Processing'),
                'title' => __('Stop Further Processing'),
                'name' => 'stop_rules_processing',
                'options' => $this->yesNoConfig->toArray()
            ]
        );

        return $mainFieldset;
    }

    /**
     * Add fields
     *
     * @param $data
     * @param \Magento\Framework\Data\Form\Element\Fieldset $fieldset
     * @param Rule $model
     * @param string $parentLabel
     */
    protected function _addAmountFields(
        $data,
        \Magento\Framework\Data\Form\Element\Fieldset $fieldset,
        Rule $model,
        $parentLabel = ''
    ) {
    
        foreach ($data as $action) {
            if (empty($action['value'])) {
                continue;
            }

            if (is_array($action['value'])) {
                $this->_addAmountFields($action['value'], $fieldset, $model, $action['label']);
            } else {
                $classes = ['validate-not-negative-number', 'hidden-field', 'amount-field', $action['value']];
                $class = implode(' ', $classes);
                $label = $action['label'];
                if ($parentLabel) {
                    $label = $parentLabel . ' [' . $label . ']';
                }
                $fieldset->addField(
                    'amount_'.$action['value'].'_value',
                    'text',
                    [
                        'name' => 'amount[' . $action['value'] . '][value]',
                        'required' => false,
                        'class' => $class,
                        'label' => $label
                    ]
                );
                $fieldset->addField(
                    'amount_'.$action['value'].'_sort',
                    'text',
                    [
                        'name' => 'amount[' . $action['value'] . '][sort]',
                        'required' => false,
                        'class' => $class,
                        'label' => 'Sort order'
                    ]
                );
            }
        }
    }

    /**
     * Return source model action type or empty array
     *
     * @return array
     */
    protected function getSourceModelActionType()
    {
        $model = $this->sourceModel;
        $modelActionType = $model->getActionType() ? $model->getActionType() : [];

        return $modelActionType;
    }

    /**
     * Return all shipping methods as option array
     *
     * @return array
     */
    protected function getShippingMethods()
    {
        return $this->shippingConfig->toOptionArray();
    }
}

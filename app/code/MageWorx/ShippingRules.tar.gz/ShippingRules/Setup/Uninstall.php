<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\ShippingRules\Setup;

use Magento\Framework\Setup\UninstallInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use MageWorx\ShippingRules\Model\Carrier;

class Uninstall implements UninstallInterface
{
    /**
     * Module uninstall code
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function uninstall(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $setup->startSetup();

        $connection = $setup->getConnection();

        $connection->dropTable($connection->getTableName('mageworx_shippingrules_customer_group'));
        $connection->dropTable($connection->getTableName('mageworx_shippingrules_store'));
        $connection->dropTable($connection->getTableName('mageworx_shippingrules'));
        $connection->dropTable($connection->getTableName(Carrier::CARRIER_TABLE_NAME));
        $connection->dropTable($connection->getTableName(Carrier::METHOD_TABLE_NAME));
        $connection->dropTable($connection->getTableName(Carrier::METHOD_LABELS_TABLE_NAME));
        $connection->dropTable($connection->getTableName(Carrier::CARRIER_LABELS_TABLE_NAME));

        $setup->endSetup();
    }
}

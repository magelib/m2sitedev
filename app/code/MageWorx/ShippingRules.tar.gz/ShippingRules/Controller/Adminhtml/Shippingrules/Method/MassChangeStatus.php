<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Method;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use MageWorx\ShippingRules\Model\ResourceModel\Method\CollectionFactory;
use MageWorx\ShippingRules\Model\Carrier\MethodFactory;

class MassChangeStatus extends Action
{
    /**
     * @var Filter
     */
    protected $filter;

    /**
     * @var string
     */
    protected $redirectUrl = '*/*/index';

    /**
     * @var CollectionFactory
     */
    protected $methodCollectionFactory;

    /**
     * @var MethodFactory
     */
    protected $methodFactory;

    /**
     * @param Context $context
     * @param Filter $filter
     * @param CollectionFactory $methodCollectionFactory
     * @param MethodFactory $methodFactory
     */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $methodCollectionFactory,
        MethodFactory $methodFactory
    ) {
        parent::__construct($context);
        $this->methodCollectionFactory = $methodCollectionFactory;
        $this->filter = $filter;
        $this->methodFactory = $methodFactory;
    }

    /**
     * Update methods's is active status
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        try {
            $collection = $this->filter->getCollection($this->methodCollectionFactory->create());
            $updatedMethodCount = 0;
            foreach ($collection->getAllIds() as $methodId) {
                $method = $this->methodFactory->create()
                    ->load($methodId);
                $method->setData('active', $this->getRequest()->getParam('active'));
                $method->getResource()->save($method);
                $updatedMethodCount++;
            }

            if ($updatedMethodCount) {
                $this->messageManager->addSuccessMessage(__('A total of %1 record(s) were updated.', $updatedMethodCount));
            }

            /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory
                ->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setPath('mageworx_shippingrules/shippingrules_method/index');

            return $resultRedirect;
        } catch (\Exception $e) {
            /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
            $this->messageManager->addErrorMessage($e->getMessage());
            $resultRedirect = $this->resultFactory
                ->create(ResultFactory::TYPE_REDIRECT);

            return $resultRedirect->setPath($this->redirectUrl);
        }
    }

    /**
     * Returns result of current user permission check on resource and privilege
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('MageWorx_ShippingRules::carrier');
    }
}

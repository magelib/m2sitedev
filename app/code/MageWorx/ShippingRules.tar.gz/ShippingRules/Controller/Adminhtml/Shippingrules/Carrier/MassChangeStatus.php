<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Carrier;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use MageWorx\ShippingRules\Model\ResourceModel\Carrier\CollectionFactory;
use MageWorx\ShippingRules\Model\CarrierFactory;

class MassChangeStatus extends Action
{
    /**
     * @var Filter
     */
    protected $filter;

    /**
     * @var string
     */
    protected $redirectUrl = '*/*/index';

    /**
     * @var CollectionFactory
     */
    protected $carrierCollectionFactory;

    /**
     * @var CarrierFactory
     */
    protected $carrierFactory;

    /**
     * @param Context $context
     * @param Filter $filter
     * @param CollectionFactory $carrierCollectionFactory
     * @param CarrierFactory $carrierFactory
     */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $carrierCollectionFactory,
        CarrierFactory $carrierFactory
    ) {
        parent::__construct($context);
        $this->carrierCollectionFactory = $carrierCollectionFactory;
        $this->filter = $filter;
        $this->carrierFactory = $carrierFactory;
    }

    /**
     * Update carriers's is active status
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        try {
            $collection = $this->filter->getCollection($this->carrierCollectionFactory->create());
            $updatedCarriersCount = 0;
            foreach ($collection->getAllIds() as $carrierId) {
                $carrier = $this->carrierFactory->create()
                    ->load($carrierId);
                $carrier->setData('active', $this->getRequest()->getParam('active'));
                $carrier->getResource()->save($carrier);
                $updatedCarriersCount++;
            }

            if ($updatedCarriersCount) {
                $this->messageManager->addSuccessMessage(__('A total of %1 record(s) were updated.', $updatedCarriersCount));
            }

            /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory
                ->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setPath('mageworx_shippingrules/shippingrules_carrier/index');

            return $resultRedirect;
        } catch (\Exception $e) {
            /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
            $this->messageManager->addErrorMessage($e->getMessage());
            $resultRedirect = $this->resultFactory
                ->create(ResultFactory::TYPE_REDIRECT);

            return $resultRedirect->setPath($this->redirectUrl);
        }
    }

    /**
     * Returns result of current user permission check on resource and privilege
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('MageWorx_ShippingRules::carrier');
    }
}

<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules;

use Magento\Backend\App\Action;

abstract class Method extends Action
{
    const BACK_TO_PARAM = 'back_to';
    const BACK_TO_CARRIER_PARAM = 'to_carrier';

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry = null;

    /**
     * @var \Magento\Framework\App\Response\Http\FileFactory
     */
    protected $fileFactory;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\Filter\Date
     */
    protected $dateFilter;

    /**
     * @var \MageWorx\ShippingRules\Model\Carrier\MethodFactory
     */
    protected $methodFactory;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory
     * @param \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter
     * @param \MageWorx\ShippingRules\Model\Carrier\MethodFactory $methodFactory
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
        \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter,
        \MageWorx\ShippingRules\Model\Carrier\MethodFactory $methodFactory,
        \Psr\Log\LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->fileFactory = $fileFactory;
        $this->dateFilter = $dateFilter;
        $this->methodFactory = $methodFactory;
        $this->logger = $logger;
    }

    /**
     * Initiate method
     *
     * @return void
     */
    protected function _init()
    {
        /** @var \MageWorx\ShippingRules\Model\Carrier\Method $method */
        $method = $this->methodFactory->create();
        $this->coreRegistry->register(
            \MageWorx\ShippingRules\Model\Carrier\Method::CURRENT_METHOD,
            $method
        );
        $id = (int)$this->getRequest()->getParam('id');

        if (!$id && $this->getRequest()->getParam('entity_id')) {
            $id = (int)$this->getRequest()->getParam('entity_id');
        }

        if ($id) {
            $this->coreRegistry->registry(\MageWorx\ShippingRules\Model\Carrier\Method::CURRENT_METHOD)->load($id);
        }
    }

    /**
     * Initiate action
     *
     * @return Quote
     */
    protected function _initAction()
    {
        $this->_view->loadLayout();
        $this->_setActiveMenu('MageWorx_ShippingRules::shippingrules_carrier')
            ->_addBreadcrumb(__('Carriers'), __('Carriers'));

        return $this;
    }

    /**
     * Check: whether it is necessary to redirect the administrator to the carrier-edit page
     *
     * @param array $data
     * @return bool
     */
    public function isBackToCarrier($data = [])
    {
        if (($this->getRequest()->getParam(static::BACK_TO_PARAM) &&
            $this->getRequest()->getParam(static::BACK_TO_PARAM == static::BACK_TO_CARRIER_PARAM))) {
            return true;
        }

        if (isset($data[static::BACK_TO_PARAM]) && $data[static::BACK_TO_PARAM] == static::BACK_TO_CARRIER_PARAM) {
            return true;
        }

        return false;
    }

    /**
     * Returns result of current user permission check on resource and privilege
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('MageWorx_ShippingRules::carrier');
    }
}

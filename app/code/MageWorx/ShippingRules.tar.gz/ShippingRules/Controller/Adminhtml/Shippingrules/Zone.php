<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules;

use MageWorx\ShippingRules\Model\Zone as ZoneModel;

abstract class Zone extends \Magento\Backend\App\Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry = null;

    /**
     * @var \MageWorx\ShippingRules\Model\ZoneFactory
     */
    protected $zoneFactory;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \MageWorx\ShippingRules\Model\ZoneFactory $zoneFactory
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \MageWorx\ShippingRules\Model\ZoneFactory $zoneFactory,
        \Psr\Log\LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->zoneFactory = $zoneFactory;
        $this->logger = $logger;
    }

    /**
     * Initiate zone
     *
     * @return void
     */
    protected function _initZone()
    {
        $zone = $this->zoneFactory->create();
        $this->coreRegistry->register(
            ZoneModel::CURRENT_ZONE,
            $zone
        );
        $id = (int)$this->getRequest()->getParam('id');

        if (!$id && $this->getRequest()->getParam('entity_id')) {
            $id = (int)$this->getRequest()->getParam('entity_id');
        }

        if ($id) {
            $this->coreRegistry->registry(ZoneModel::CURRENT_ZONE)->load($id);
        }
    }

    /**
     * Initiate action
     *
     * @return Zone
     */
    protected function _initAction()
    {
        $this->_view->loadLayout();

        return $this;
    }

    /**
     * Returns result of current user permission check on resource and privilege
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('MageWorx_ShippingRules::zone');
    }
}

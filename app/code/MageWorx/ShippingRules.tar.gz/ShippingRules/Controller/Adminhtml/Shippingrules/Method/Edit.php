<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Method;

use \MageWorx\ShippingRules\Model\Carrier\Method;

class Edit extends \MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Method
{
    /**
     * Method edit action
     *
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        /** @var \MageWorx\ShippingRules\Model\Carrier\Method $model */
        $model = $this->methodFactory->create();

        if ($id) {
            $model->load($id);
            if (!$model->getEntityId()) {
                $this->messageManager->addErrorMessage(__('This method no longer exists.'));
                $this->_redirect('mageworx_shippingrules/*');
                return;
            }
        }

        // set entered data if was error when we do save
        $data = $this->_session->getPageData(true);
        if (!empty($data)) {
            $model->addData($data);
        }

        $this->_session->setData('mw_current_sMethod_id', $model->getId());
        $this->coreRegistry->register(Method::CURRENT_METHOD, $model);
        $this->_initAction();
        $this->_addBreadcrumb($id ? __('Edit Method') : __('New Method'), $id ? __('Edit Method') : __('New Method'));

        $this->_view->getPage()->getConfig()->getTitle()->prepend(
            $model->getEntityId() ? $model->getTitle() : __('New Method')
        );
        $this->_view->renderLayout();
    }
}

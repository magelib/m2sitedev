<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Carrier;

class Edit extends \MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Carrier
{
    /**
     * Carrier edit action
     *
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        /** @var \MageWorx\ShippingRules\Model\Carrier $model */
        $model = $this->carrierFactory->create();

        if ($id) {
            $model->load($id);
            if (!$model->getCarrierId()) {
                $this->messageManager->addErrorMessage(__('This carrier no longer exists.'));
                $this->_redirect('mageworx_shippingrules/*');
                return;
            }
        }

        // set entered data if was error when we do save
        $data = $this->_session->getPageData(true);
        if (!empty($data)) {
            $model->addData($data);
        }

        $this->coreRegistry->register('current_carrier', $model);
        $this->_initAction();
        $breadcrumb = $id ? __('Edit Carrier') : __('New Carrier');
        $this->_addBreadcrumb($breadcrumb, $breadcrumb);

        $title = $model->getCarrierId() ? $model->getName() : __('New Carrier');
        $this->_view->getPage()->getConfig()->getTitle()->prepend($title);
        $this->_view->renderLayout();
    }
}

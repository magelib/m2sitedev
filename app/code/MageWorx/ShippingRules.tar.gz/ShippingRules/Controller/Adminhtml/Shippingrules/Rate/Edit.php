<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Rate;

use \MageWorx\ShippingRules\Model\Carrier\Method\Rate;

class Edit extends \MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Rate
{
    /**
     * Rate edit action
     *
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        if (!$id) {
            $id = $this->getRequest()->getParam('rate_id');
        }
        /** @var \MageWorx\ShippingRules\Model\Carrier\Method\Rate $model */
        $model = $this->rateFactory->create();

        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addErrorMessage(__('This rate no longer exists.'));
                $this->_redirect('mageworx_shippingrules/*');
                return;
            }
        }

        // set entered data if was error when we do save
        $data = $this->_session->getPageData(true);
        if (!empty($data)) {
            $model->addData($data);
        }

        $this->coreRegistry->register(Rate::CURRENT_RATE, $model);
        $this->_initAction();
        $this->_addBreadcrumb($id ? __('Edit Rate') : __('New Rate'), $id ? __('Edit Rate') : __('New Rate'));

        $this->_view->getPage()->getConfig()->getTitle()->prepend(
            $model->getId() ? $model->getTitle() : __('New Rate')
        );
        $this->_view->renderLayout();
    }
}

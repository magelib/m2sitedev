<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Zone;

use \MageWorx\ShippingRules\Model\Zone as ZoneModel;

class Edit extends \MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Zone
{
    /**
     * Shipping zone edit action
     *
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        /** @var ZoneModel $model */
        $model = $this->zoneFactory->create();

        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addErrorMessage(__('This zone no longer exists.'));
                $this->_redirect('mageworx_shippingrules/*');
                return;
            }
        }

        // set entered data if was error when we do save
        $data = $this->_session->getPageData(true);
        if (!empty($data)) {
            $model->addData($data);
        }

        $model->getConditions()->setJsFormObject('zone_conditions_fieldset');
        $model->getActions()->setJsFormObject('zone_actions_fieldset');

        $this->coreRegistry->register(ZoneModel::CURRENT_ZONE, $model);

        $this->_initAction();
        $this->_view->getLayout()
            ->getBlock('shippingrules_zone_edit')
            ->setData('action', $this->getUrl('mageworx_shippingrules/*/save'));

        $this->_addBreadcrumb($id ? __('Edit Zone') : __('New Zone'), $id ? __('Edit Zone') : __('New Zone'));

        $this->_view->getPage()->getConfig()->getTitle()->prepend(
            $model->getId() ? $model->getName() : __('New Shipping Zone')
        );
        $this->_view->renderLayout();
    }
}

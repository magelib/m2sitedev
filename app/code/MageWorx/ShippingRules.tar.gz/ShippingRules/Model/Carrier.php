<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Model;

use Magento\Framework\DataObject;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;

/**
 * Class Carrier
 *
 * @method int|null getCarrierId()
 * @method Carrier setCarrierId(int $id)
 * @method string getCarrierCode()
 * @method Carrier setCarrierCode(string $code)
 * @method string getName()
 * @method Carrier setName(string $name)
 * @method string getTitle()
 * @method Carrier setTitle(string $title)
 * @method \MageWorx\ShippingRules\Model\ResourceModel\Carrier _getResource()
 * @method \MageWorx\ShippingRules\Model\ResourceModel\Carrier getResource()
 *
 */
class Carrier extends \Magento\Framework\Model\AbstractExtensibleModel
{
    const CURRENT_CARRIER = 'current_carrier';

    const CARRIER_TABLE_NAME = 'mageworx_shippingrules_carrier';
    const METHOD_TABLE_NAME = 'mageworx_shippingrules_methods';
    const RATE_TABLE_NAME = 'mageworx_shippingrules_rates';
    const CARRIER_LABELS_TABLE_NAME = 'mageworx_shippingrules_carrier_label';
    const METHOD_LABELS_TABLE_NAME = 'mageworx_shippingrules_methods_label';

    const DEFAULT_MODEL = 'MageWorx\ShippingRules\Model\Carrier\Artificial';
    const DEFAULT_TYPE = 'I';
    const DEFAULT_ERROR_MESSAGE =
        'This shipping method is not available. To use this shipping method, please contact us.';

    /**
     * @var \MageWorx\ShippingRules\Model\ResourceModel\Method\Collection
     */
    protected $methodsCollection;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ExtensionAttributesFactory $extensionFactory,
        AttributeValueFactory $customAttributeFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->storeManager = $storeManager;
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $resource,
            $resourceCollection,
            $data
        );
    }

    /**
     * Set resource model and Id field name
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init('MageWorx\ShippingRules\Model\ResourceModel\Carrier');
        $this->setIdFieldName('carrier_id');
    }

    public function afterLoad()
    {
        $this->getResource()->afterLoad($this);
        $storeId = $this->storeManager->getStore()->getId();
        $label = $this->getStoreLabel($storeId);
        if ($label) {
            $this->setTitle($label);
        }
        parent::afterLoad();
    }

    /**
     * @return ResourceModel\Method\Collection
     */
    public function getMethodsCollection()
    {
        return $this->methodsCollection;
    }

    /**
     * @param ResourceModel\Method\Collection $methods
     * @return $this
     */
    public function setMethodsCollection(\MageWorx\ShippingRules\Model\ResourceModel\Method\Collection $methods)
    {
        $this->methodsCollection = $methods;
        return $this;
    }

    /**
     * Validate model data
     *
     * @param DataObject $dataObject
     * @return bool
     */
    public function validateData(DataObject $dataObject)
    {
        $errors = [];

        if (!$dataObject->getCarrierCode()) {
            $errors[] = __('Carrier code is required');
        }

        if (!empty($errors)) {
            return $errors;
        }

        return true;
    }

    /**
     * Get Carrier label by specified store
     *
     * @param \Magento\Store\Model\Store|int|bool|null $store
     * @return string|bool
     */
    public function getStoreLabel($store = null)
    {
        $storeId = $this->storeManager->getStore($store)->getId();
        $labels = (array)$this->getStoreLabels();

        if (isset($labels[$storeId])) {
            return $labels[$storeId];
        } elseif (isset($labels[0]) && $labels[0]) {
            return $labels[0];
        }

        return false;
    }

    /**
     * Set if not yet and retrieve carrier store labels
     *
     * @return array
     */
    public function getStoreLabels()
    {
        if (!$this->hasStoreLabels()) {
            $labels = $this->_getResource()->getStoreLabels($this->getId());
            $this->setStoreLabels($labels);
        }

        return $this->_getData('store_labels');
    }

    /**
     * Initialize carrier model data from array.
     * Set store labels if applicable.
     *
     * @param array $data
     * @return $this
     */
    public function loadPost(array $data)
    {
        if (isset($data['store_labels'])) {
            $this->setStoreLabels($data['store_labels']);
        }

        return $this;
    }
}

<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Model;

use Magento\Framework\DataObject;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Rule\Model\AbstractModel;

/**
 * Class Zone
 *
 * @method int|null getZoneId()
 * @method Zone setZoneId(int $id)
 * @method string getName()
 * @method Zone setName(string $name)
 * @method string getTitle()
 * @method Zone setTitle(string $title)
 * @method \MageWorx\ShippingRules\Model\ResourceModel\Zone _getResource()
 * @method \MageWorx\ShippingRules\Model\ResourceModel\Zone getResource()
 *
 */
class Zone extends AbstractModel
{
    const CURRENT_ZONE = 'current_zone';
    const ZONE_TABLE_NAME = 'mageworx_shippingrules_zone';
    const ZONE_STORE_TABLE_NAME = 'mageworx_shippingrules_zone_store';

    /**
     * @var \MageWorx\ShippingRules\Model\Zone\Condition\CombineFactory
     */
    protected $condCombineFactory;

    /**
     * @var \Magento\Rule\Model\Action\CollectionFactory
     */
    protected $actionsCollectionFactory;

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate
     * @param Zone\Condition\CombineFactory $condCombineFactory
     * @param \Magento\Rule\Model\Action\CollectionFactory $actionsCollectionFactory
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \MageWorx\ShippingRules\Model\Zone\Condition\CombineFactory $condCombineFactory,
        \Magento\Rule\Model\Action\CollectionFactory $actionsCollectionFactory,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->condCombineFactory = $condCombineFactory;
        $this->actionsCollectionFactory = $actionsCollectionFactory;
        parent::__construct(
            $context,
            $registry,
            $formFactory,
            $localeDate,
            $resource,
            $resourceCollection,
            $data
        );
    }

    /**
     * Set resource model and Id field name
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init('MageWorx\ShippingRules\Model\ResourceModel\Zone');
        $this->setIdFieldName('entity_id');
    }

    public function afterLoad()
    {
        $this->getResource()->afterLoad($this);
        parent::afterLoad();
    }

    /**
     * Validate model data
     *
     * @param DataObject $dataObject
     * @return bool|array
     */
    public function validateData(DataObject $dataObject)
    {
        $errors = parent::validateData($dataObject);

        if (!$dataObject->getName()) {
            $errors[] = __('Zone name is required');
        }

        if (!empty($errors)) {
            return $errors;
        }

        return true;
    }

    /**
     * Initialize zone model data from array.
     *
     * @param array $data
     * @return $this
     */
    public function loadPost(array $data)
    {
        parent::loadPost($data);

        return $this;
    }

    /**
     * Get zone condition combine model instance
     *
     * @return \MageWorx\ShippingRules\Model\Zone\Condition\Combine
     */
    public function getConditionsInstance()
    {
        return $this->condCombineFactory->create();
    }

    /**
     * Get zone actions instance
     *
     * @return \Magento\Rule\Model\Action\Collection
     */
    public function getActionsInstance()
    {
        $factory = $this->actionsCollectionFactory;
        $result = $factory->create();

        return $result;
    }
}

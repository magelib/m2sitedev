<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;

class Method extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Magento string lib
     *
     * @var \Magento\Framework\Stdlib\StringUtils
     */
    protected $string;

    /**
     * @var \MageWorx\ShippingRules\Model\ResourceModel\Rate\CollectionFactory
     */
    protected $rateCollectionFactory;

    /**
     * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
     * @param \Magento\Framework\Stdlib\StringUtils $string
     * @param Rate\CollectionFactory $rateCollectionFactory
     * @param null $connectionName
     */
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        \Magento\Framework\Stdlib\StringUtils $string,
        \MageWorx\ShippingRules\Model\ResourceModel\Rate\CollectionFactory $rateCollectionFactory,
        $connectionName = null
    ) {
        $this->string = $string;
        $this->rateCollectionFactory = $rateCollectionFactory;
        parent::__construct($context, $connectionName);
    }

    /**
     * Initialize main table and table id field
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\MageWorx\ShippingRules\Model\Carrier::METHOD_TABLE_NAME, 'entity_id');
    }

    /**
     * Add customer group ids and store ids to rule data after load
     *
     * @param AbstractModel $object
     * @return $this
     */
    protected function _afterLoad(AbstractModel $object)
    {
        parent::_afterLoad($object);
        $this->addRates($object);

        return $this;
    }

    /**
     * @param AbstractModel $object
     * @return $this
     */
    public function _beforeSave(AbstractModel $object)
    {
        parent::_beforeSave($object);
        return $this;
    }

    /**
     * Save method's associated store labels.
     *
     * @param \Magento\Framework\Model\AbstractModel $object
     * @return $this
     */
    protected function _afterSave(AbstractModel $object)
    {
        if ($object->hasStoreLabels()) {
            $this->saveStoreLabels($object->getId(), $object->getStoreLabels());
        }

        return parent::_afterSave($object);
    }

    /**
     * Save carrier labels for different store views
     *
     * @param int $methodId
     * @param array $labels
     * @throws \Exception
     * @return $this
     */
    public function saveStoreLabels($methodId, $labels)
    {
        $deleteByStoreIds = [];
        $table = $this->getTable(\MageWorx\ShippingRules\Model\Carrier::METHOD_LABELS_TABLE_NAME);
        $connection = $this->getConnection();

        $data = [];
        foreach ($labels as $storeId => $label) {
            if ($this->string->strlen($label)) {
                $data[] = ['method_id' => $methodId, 'store_id' => $storeId, 'label' => $label];
            } else {
                $deleteByStoreIds[] = $storeId;
            }
        }

        $connection->beginTransaction();
        try {
            if (!empty($data)) {
                $connection->insertOnDuplicate($table, $data, ['label']);
            }

            if (!empty($deleteByStoreIds)) {
                $connection->delete($table, ['method_id=?' => $methodId, 'store_id IN (?)' => $deleteByStoreIds]);
            }
        } catch (\Exception $e) {
            $connection->rollback();
            throw $e;
        }
        $connection->commit();

        return $this;
    }

    /**
     * Get all existing carrier labels
     *
     * @param int $methodId
     * @return array
     */
    public function getStoreLabels($methodId)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable(\MageWorx\ShippingRules\Model\Carrier::METHOD_LABELS_TABLE_NAME),
            ['store_id', 'label']
        )->where(
            'method_id = :method_id'
        );
        return $this->getConnection()->fetchPairs($select, [':method_id' => $methodId]);
    }

    /**
     * Get carrier label by specific store id
     *
     * @param int $methodId
     * @param int $storeId
     * @return string
     */
    public function getStoreLabel($methodId, $storeId)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable(\MageWorx\ShippingRules\Model\Carrier::METHOD_LABELS_TABLE_NAME),
            'label'
        )->where(
            'method_id = :method_id'
        )->where(
            'store_id IN(0, :store_id)'
        )->order(
            'store_id DESC'
        );
        return $this->getConnection()->fetchOne($select, [':method_id' => $methodId, ':store_id' => $storeId]);
    }


    /**
     * Adds corresponding shipping rates to the method
     * @param AbstractModel $object
     */
    public function addRates(AbstractModel $object)
    {
        /** @var \MageWorx\ShippingRules\Model\ResourceModel\Rate\Collection $rates */
        $rates = $this->getRatesCollection($object);
        $object->setRates($rates->getItems());
    }

    /**
     * @param AbstractModel $object
     * @return Rate\Collection
     */
    public function getRatesCollection(AbstractModel $object)
    {
        /** @var \MageWorx\ShippingRules\Model\ResourceModel\Rate\Collection $rates */
        $rates = $this->rateCollectionFactory->create();
        $rates->addFieldToFilter('method_id', $object->getId());
        $rates->addOrder('priority');
        $object->setRatesCollection($rates);

        return $rates;
    }
}

<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\ShippingRules\Model;

use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\RateResult\Method;

/**
 * Shipping Rule data model
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 *
 * @method array getActionType()
 * @method Rule setActionType(string $type)
 * @method string getShippingMethods()
 * @method Rule setShippingMethods(string $methods)
 * @method array getAmount()
 * @method Rule setAmount(float $amount)
 * @method string getSimpleAction()
 * @method Rule setSimpleAction(string $action)
 * @method bool getStopRulesProcessing()
 * @method Rule setStopRulesProcessing($flag)
 * @method array getDisabledShippingMethods()
 * @method Rule setDisabledShippingMethods($methods)
 *
 * Days of week in PHP: from 0 to 6
 * @method int getDaysOfWeek()
 * @method Rule setDaysOfWeek($int)
 *
 *
 * Time from & to in minutes from 0 to 1440
 * @method int getTimeFrom()
 * @method Rule setTimeFrom($time)
 * @method int getTimeTo()
 * @method Rule setTimeTo($time)
 *
 * @method bool getUseTime()
 * @method Rule setUseTime($bool)
 * @method bool getTimeEnabled()
 * @method Rule setTimeEnabled($bool)
 */
class Rule extends \Magento\Rule\Model\AbstractModel
{

    /**
     * Rule possible actions
     */
    const ACTION_OVERWRITE_COST  = 'overwrite';
    const ACTION_DISABLE_SM  = 'disable';

    // Matrix
    const ACTION_CALCULATION_FIXED = 'fixed';
    const ACTION_CALCULATION_PERCENT = 'percent';

    const ACTION_METHOD_OVERWRITE = 'overwrite';
    const ACTION_METHOD_SURCHARGE = 'surcharge';
    const ACTION_METHOD_DISCOUNT = 'discount';

    const ACTION_TYPE_AMOUNT = 'amount';
    const ACTION_TYPE_PER_QTY_OF_ITEM = 'product'; // per Qty of Item
    const ACTION_TYPE_PER_ITEM = 'item';
    const ACTION_TYPE_PER_WEIGHT_UNIT = 'weight';

    const FREE_SHIPPING_CODE = 'freeshipping_freeshipping';

    const ENABLED = 1;
    const DISABLED = 0;

    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'mageworx_shippingrules_rule';

    /**
     * Parameter name in event
     *
     * In observe method you can use $observer->getEvent()->getRule() in this case
     *
     * @var string
     */
    protected $_eventObject = 'rule';

    /**
     * Store already validated addresses and validation results
     *
     * @var array
     */
    protected $validatedAddresses = [];

    /** @var \MageWorx\ShippingRules\Model\Rule\Condition\CombineFactory */
    protected $condCombineFactory;

    /** @var \MageWorx\ShippingRules\Model\Rule\Condition\Product\CombineFactory */
    protected $condProdCombineF;

    /** @var \Magento\Store\Model\StoreManagerInterface */
    protected $storeManager;

    /**
     * @return array
     */
    public static function getActionCalculations()
    {
        return [
            self::ACTION_CALCULATION_FIXED,
            self::ACTION_CALCULATION_PERCENT
        ];
    }

    /**
     * @return array
     */
    public static function getActionMethods()
    {
        return [
            self::ACTION_METHOD_OVERWRITE,
            self::ACTION_METHOD_SURCHARGE,
            self::ACTION_METHOD_DISCOUNT
        ];
    }

    /**
     * @return array
     */
    public static function getActionTypes()
    {
        return [
            self::ACTION_TYPE_AMOUNT,
            self::ACTION_TYPE_PER_QTY_OF_ITEM,
            self::ACTION_TYPE_PER_ITEM,
            self::ACTION_TYPE_PER_WEIGHT_UNIT,
        ];
    }

    /**
     * Get calculation matrix as array
     *
     * @return array
     */
    public static function getCalculationMatrix()
    {
        $calculations = self::getActionCalculations();
        $methods = self::getActionMethods();
        $types = self::getActionTypes();

        $matrix = [];

        foreach ($calculations as $calculation) {
            foreach ($methods as $method) {
                foreach ($types as $type) {
                    $key = implode('_', [$calculation, $method, $type]);
                    $matrix[$key] = $key;
                }
            }
        }

        return $matrix;
    }

    /**
     * @param Method $rate
     * @return string
     */
    public static function getMethodCode(Method $rate)
    {
        /** @var string $methodCode */
        $methodCode = $rate->getCarrier() . '_' . $rate->getMethod();
        return $methodCode;
    }

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate
     * @param \MageWorx\ShippingRules\Model\Rule\Condition\CombineFactory $condCombineFactory
     * @param \Magento\SalesRule\Model\Rule\Condition\Product\CombineFactory $condProdCombineF
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb $resourceCollection
     * @param array $data
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \MageWorx\ShippingRules\Model\Rule\Condition\CombineFactory $condCombineFactory,
        \MageWorx\ShippingRules\Model\Rule\Condition\Product\CombineFactory $condProdCombineF,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->condCombineFactory = $condCombineFactory;
        $this->condProdCombineF = $condProdCombineF;
        $this->storeManager = $storeManager;
        parent::__construct($context, $registry, $formFactory, $localeDate, $resource, $resourceCollection, $data);
    }

    /**
     * Set resource model and Id field name
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init('MageWorx\ShippingRules\Model\ResourceModel\Rule');
        $this->setIdFieldName('rule_id');
    }

    /**
     * Get rule condition combine model instance
     *
     * @return \MageWorx\ShippingRules\Model\Rule\Condition\Combine
     */
    public function getConditionsInstance()
    {
        return $this->condCombineFactory->create();
    }

    /**
     * Get rule condition product combine model instance
     *
     * @return \MageWorx\ShippingRules\Model\Rule\Condition\Product\Combine
     */
    public function getActionsInstance()
    {
        $factory = $this->condProdCombineF;
        $result = $factory->create();

        return $result;
    }

    /**
     * Get sales rule customer group Ids
     *
     * @return array
     */
    public function getCustomerGroupIds()
    {
        if (!$this->hasCustomerGroupIds()) {
            $customerGroupIds = $this->_getResource()->getCustomerGroupIds($this->getId());
            $this->setData('customer_group_ids', (array)$customerGroupIds);
        }
        return $this->_getData('customer_group_ids');
    }

    /**
     * Check cached validation result for specific address
     *
     * @param Address $address
     * @return bool
     */
    public function hasIsValidForAddress($address)
    {
        $addressId = $this->_getAddressId($address);
        return isset($this->validatedAddresses[$addressId]) ? true : false;
    }

    /**
     * Set validation result for specific address to results cache
     *
     * @param Address $address
     * @param bool $validationResult
     * @return $this
     */
    public function setIsValidForAddress($address, $validationResult)
    {
        $addressId = $this->_getAddressId($address);
        $this->validatedAddresses[$addressId] = $validationResult;
        return $this;
    }

    /**
     * Get cached validation result for specific address
     *
     * @param Address $address
     * @return bool
     * @SuppressWarnings(PHPMD.BooleanGetMethodName)
     */
    public function getIsValidForAddress($address)
    {
        $addressId = $this->_getAddressId($address);
        return isset($this->validatedAddresses[$addressId]) ? $this->validatedAddresses[$addressId] : false;
    }

    /**
     * Return id for address
     *
     * @param Address $address
     * @return string
     */
    private function _getAddressId($address)
    {
        if ($address instanceof Address) {
            return $address->getId();
        }
        return $address;
    }

    /**
     * Prepare data before saving
     *
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function beforeSave()
    {
        /**
         * Prepare store Ids if applicable and if they were set as string in comma separated format.
         * Backwards compatibility.
         */
        if ($this->hasStoreIds()) {
            $storeIds = $this->getStoreIds();
            if (!empty($storeIds)) {
                $this->setStoreIds($storeIds);
            }
        }

        parent::beforeSave();
        return $this;
    }

    /**
     * Get rule associated store Ids
     *
     * @return array
     */
    public function getStoreIds()
    {
        if (!$this->hasStoreIds()) {
            $storeIds = $this->_getResource()->getStoreIds($this->getId());
            $this->setData('store_ids', (array)$storeIds);
        }
        return $this->getData('store_ids');
    }

    /**
     * @param string $formName
     * @return string
     */
    public function getActionsFieldSetId($formName = '')
    {
        return $formName . 'rule_actions_fieldset_' . $this->getId();
    }

    /**
     * Get all shipping methods affected by rule (from the change price & disable sections both)
     *
     * @return array
     */
    public function getAffectedShippingMethods()
    {
        $shippingMethods = !empty($this->getShippingMethods()) ? $this->getShippingMethods() : [];
        $disabledShippingMethods = !empty($this->getDisabledShippingMethods()) ?
            $this->getDisabledShippingMethods() :
            [];
        $affectShippingMethods = array_merge($shippingMethods, $disabledShippingMethods);

        return $affectShippingMethods;
    }

    public function afterLoad()
    {
        $this->getResource()->afterLoad($this);
        parent::afterLoad();

        return $this;
    }
}

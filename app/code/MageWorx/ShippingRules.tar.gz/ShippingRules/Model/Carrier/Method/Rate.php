<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\ShippingRules\Model\Carrier\Method;

use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\DataObject;
use Magento\Quote\Model\Quote\Address\RateRequest;

/**
 * Class Rate
 *
 * @method int|null getMethodId()
 * @method Rate setMethodId(int)
 * @method int getActive()
 * @method string getCountryId()
 * @method Rate setCountryId(string $countryId)
 * @method string getRegionId()
 * @method Rate setRegionId(string $regionId)
 * @method string getRegion()
 * @method Rate setRegion(string $region)
 * @method string getZipFrom()
 * @method string getZipTo()
 * @method float getPriceFrom()
 * @method float getPriceTo()
 * @method float getQtyFrom()
 * @method float getQtyTo()
 * @method float getWeightFrom()
 * @method float getWeightTo()
 * @method float getPrice()
 * @method float getPricePerProduct()
 * @method float getPricePerItem()
 * @method float getPricePercentPerProduct()
 * @method float getPricePercentPerItem()
 * @method float getItemPricePercent()
 * @method float getPricePerWeight()
 * @method string getTitle()
 * @method Rate setTitle(string $title)
 * @method int getPriority()
 * @method Rate setPriority(int $priority)
 * @method int getRateMethodPrice()
 * @method Rate setRateMethodPrice(int $rateMethodPrice)
 *
 */
class Rate extends \Magento\Framework\Model\AbstractExtensibleModel
{
    const CURRENT_RATE = 'current_rate';

    const PRICE_CALCULATION_OVERWRITE = 0;
    const PRICE_CALCULATION_SUM = 1;

    const MULTIPLE_RATES_PRICE_CALCULATION_MAX_PRIORITY = 0;
    const MULTIPLE_RATES_PRICE_CALCULATION_MAX_PRICE = 1;
    const MULTIPLE_RATES_PRICE_CALCULATION_MIN_PRICE = 2;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ExtensionAttributesFactory $extensionFactory,
        AttributeValueFactory $customAttributeFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->storeManager = $storeManager;
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $resource,
            $resourceCollection,
            $data
        );
    }

    /**
     * Set resource model and Id field name
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init('MageWorx\ShippingRules\Model\ResourceModel\Rate');
        $this->setIdFieldName('rate_id');
    }

    /**
     * After load
     */
    public function afterLoad()
    {
        $this->getResource()->afterLoad($this);
        parent::afterLoad();
    }

    /**
     * Validate model data
     *
     * @param DataObject $dataObject
     * @return bool|array
     */
    public function validateData(DataObject $dataObject)
    {
        $errors = [];

        if (!empty($errors)) {
            return $errors;
        }

        return true;
    }

    /**
     * @param \Magento\Quote\Model\Quote\Address\RateResult\Method $method
     * @param RateRequest $request
     * @return \Magento\Quote\Model\Quote\Address\RateResult\Method
     */
    public function applyRateToMethod(
        \Magento\Quote\Model\Quote\Address\RateResult\Method $method,
        RateRequest $request,
        \MageWorx\ShippingRules\Model\Carrier\Method $methodData
    ) {
        $result = $this->getCalculatedPrice($request, $methodData);
        $method->setPrice($result);

        // Change method title
        if ($this->getTitle()) {
            $method->setMethodTitle($this->getTitle());
        }

        return $method;
    }

    public function getCalculatedPrice(
        RateRequest $request,
        \MageWorx\ShippingRules\Model\Carrier\Method $methodData
    ) {
        $requestItemsCount = count($request->getAllItems());
        $requestItemsCost = $this->calculateItemsTotalPrice($request->getAllItems());

        $price['base_rice'] = $this->getPrice();
        $price['per_product'] = $request->getPackageQty() * $this->getPricePerProduct();
        $price['per_item'] = $requestItemsCount * $this->getPricePerItem();
        $price['percent_per_product'] = $request->getPackageQty() * $this->getPricePercentPerProduct() / 100;
        $price['percent_per_item'] = $requestItemsCount * $this->getPricePercentPerItem() / 100;
        $price['item_price_percent'] = $requestItemsCost * $this->getItemPricePercent() / 100;
        $price['per_weight'] = $request->getPackageWeight() * $this->getPricePerWeight();

        $result = array_sum($price);
        if ($this->getRateMethodPrice() == self::PRICE_CALCULATION_SUM) {
            $result += $methodData->getData('price');
        }

        return $result;
    }

    /**
     * @param $items
     * @return float
     */
    public function calculateItemsTotalPrice($items)
    {
        $totalPrice = 0.0;
        /** @var \Magento\Quote\Model\Quote\Item $item */
        foreach ($items as $item) {
            $totalPrice += $item->getBaseRowTotal(); // @TODO: with tax? without discount?
            // @TODO: possible add settings to the module config
        }

        return $totalPrice;
    }

    /**
     * @param RateRequest $request
     * @return bool
     */
    public function validateRequest(RateRequest $request)
    {
        // Not active rates are invalid
        if (!$this->getActive()) {
            return false;
        }

        // Validate country
        if ($this->getCountryId() && $request->getDestCountryId() != $this->getCountryId()) {
            return false;
        }

        // Validate region
        if ($this->getRegionId() && $request->getDestRegionId() != $this->getRegionId()) {
            return false;
        } elseif ($this->getRegion() && $request->getDestRegionCode() != $this->getRegion()) {
            return false;
        }

        if (!$this->validateRequestByZipCode($request)) {
            return false;
        }

        if (!$this->validateRequestByPrice($request)) {
            return false;
        }

        if (!$this->validateRequestByQty($request)) {
            return false;
        }

        if (!$this->validateRequestByWeight($request)) {
            return false;
        }

        return true;
    }

    /**
     * @param RateRequest $request
     * @return bool
     */
    public function validateRequestByZipCode(RateRequest $request)
    {
        if (!$this->getZipFrom() && !$this->getZipTo()) {
            return true;
        }

        $requestZip = $request->getDestPostcode();
        if ($this->getZipFrom() == $this->getZipTo() && $requestZip == $this->getZipFrom()) {
            return true;
        }

        if ($requestZip < $this->getZipFrom()) {
            return false;
        }

        if ($this->getZipTo() && $requestZip > $this->getZipTo()) {
            return false;
        }

        return true;
    }

    /**
     * @param RateRequest $request
     * @return bool
     */
    public function validateRequestByPrice(RateRequest $request)
    {
        if (!$this->getPriceFrom() && !$this->getPriceTo()) {
            return true;
        }

        $requestPrice = $request->getPackageValue();
        if ($this->getPriceFrom() == $this->getPriceTo() && $requestPrice == $this->getPriceFrom()) {
            return true;
        }

        if ($requestPrice < $this->getPriceFrom()) {
            return false;
        }

        if ($this->getPriceTo() != 0 && $requestPrice > $this->getPriceTo()) {
            return false;
        }

        return true;
    }

    /**
     * @param RateRequest $request
     * @return bool
     */
    public function validateRequestByQty(RateRequest $request)
    {
        if (!$this->getQtyFrom() && !$this->getQtyTo()) {
            return true;
        }

        $requestQty = $request->getPackageQty();
        if ($this->getQtyFrom() == $this->getQtyTo() && $requestQty == $this->getQtyFrom()) {
            return true;
        }

        if ($requestQty < $this->getQtyFrom()) {
            return false;
        }

        if ($this->getQtyTo() != 0 && $requestQty > $this->getQtyTo()) {
            return false;
        }

        return true;
    }

    /**
     * @param RateRequest $request
     * @return bool
     */
    public function validateRequestByWeight(RateRequest $request)
    {
        if (!$this->getWeightFrom() && !$this->getWeightTo()) {
            return true;
        }

        $requestWeight = $request->getPackageWeight();
        if ($this->getWeightFrom() == $this->getWeightTo() && $requestWeight == $this->getWeightFrom()) {
            return true;
        }

        if ($requestWeight < $this->getWeightFrom()) {
            return false;
        }

        if ($this->getWeightTo() != 0 && $requestWeight > $this->getWeightTo()) {
            return false;
        }

        return true;
    }
}

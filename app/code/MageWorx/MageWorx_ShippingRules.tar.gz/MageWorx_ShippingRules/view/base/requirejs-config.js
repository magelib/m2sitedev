/**
 * Copyright © 2017 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
var config = {
    map: {
        '*': {
            'slick'       : 'MageWorx_ShippingRules/js/slick',
            'slickWrapper': 'MageWorx_ShippingRules/js/slickWrapper'
        }
    }
};
